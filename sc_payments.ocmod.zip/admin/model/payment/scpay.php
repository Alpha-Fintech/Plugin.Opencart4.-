<?php
namespace Opencart\Admin\Model\Extension\ScPayments\Payment;
class SCPay extends \Opencart\System\Engine\Model {
	public function charge(int $customer_id, int $customer_payment_id, float $amount): int {
		$this->load->language('extension/sc_payments/payment/scpay');

		$json = [];

		if (!$json) {

		}

		return $this->config->get('config_subscription_active_status_id');
	}
}
