<?php
namespace Opencart\Admin\Controller\Extension\ScPayments\Payment;
class SCPay extends \Opencart\System\Engine\Controller {
	public function index(): void {
		
		$this->load->language('extension/sc_payments/payment/scpay');

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/sc_payments/payment/scpay', 'user_token=' . $this->session->data['user_token'])
		];

		$data['save'] = $this->url->link('extension/sc_payments/payment/scpay|save', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');

		$data['payment_scpay_merchant'] = $this->config->get('payment_scpay_merchant');
		$data['payment_scpay_password'] = $this->config->get('payment_scpay_password');
		$data['payment_scpay_redirect'] = HTTP_CATALOG . 'index.php?route=extension/sc_payments/payment/scpay|redirect';
		$data['payment_scpay_environment'] = $this->config->get('payment_scpay_environment');
		$data['payment_scpay_total'] = $this->config->get('payment_scpay_total'); 

		$Config_scpay_order_status_id = $this->config->get('payment_scpay_order_status_id');
		if (isset($this->request->post['payment_scpay_order_status_id'])) {
			$data['payment_scpay_order_status_id'] = $this->request->post['payment_scpay_order_status_id'];
		} elseif(empty($Config_scpay_order_status_id)){
			$data['payment_scpay_order_status_id'] = 1;
		}else {
			$data['payment_scpay_order_status_id'] = $this->config->get('payment_scpay_order_status_id'); 
		}
		
		$Config_scpay_success_status_id = $this->config->get('payment_scpay_success_status_id');
		if (isset($this->request->post['payment_scpay_success_status_id'])) {
			$data['payment_scpay_success_status_id'] = $this->request->post['payment_scpay_success_status_id'];
		} elseif(empty($Config_scpay_success_status_id)){
			$data['payment_scpay_success_status_id'] = 2;
		}else {
			$data['payment_scpay_success_status_id'] = $this->config->get('payment_scpay_success_status_id'); 
		} 
		
		$Config_scpay_failed_status_id = $this->config->get('payment_scpay_failed_status_id');
		if (isset($this->request->post['payment_scpay_failed_status_id'])) {
			$data['payment_scpay_failed_status_id'] = $this->request->post['payment_scpay_failed_status_id'];
		} elseif(empty($Config_scpay_failed_status_id)){
			$data['payment_scpay_failed_status_id'] = 10;
		}else {
			$data['payment_scpay_failed_status_id'] = $this->config->get('payment_scpay_failed_status_id'); 
		} 
		
		$Config_scpay_cancel_status_id = $this->config->get('payment_scpay_cancel_status_id');
		if (isset($this->request->post['payment_scpay_cancel_status_id'])) {
			$data['payment_scpay_cancel_status_id'] = $this->request->post['payment_scpay_cancel_status_id'];
		} elseif(empty($Config_scpay_cancel_status_id)){
			$data['payment_scpay_cancel_status_id'] = 7;
		}else {
			$data['payment_scpay_cancel_status_id'] = $this->config->get('payment_scpay_cancel_status_id'); 
		} 
		
		$Config_scpay_pending_status_id = $this->config->get('payment_scpay_pending_status_id');
		if (isset($this->request->post['payment_scpay_pending_status_id'])) {
			$data['payment_scpay_pending_status_id'] = $this->request->post['payment_scpay_pending_status_id'];
		} elseif(empty($Config_scpay_pending_status_id)){
			$data['payment_scpay_pending_status_id'] = 1;
		}else {
			$data['payment_scpay_pending_status_id'] = $this->config->get('payment_scpay_pending_status_id'); 
		} 

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		// $data['payment_scpay_geo_zone_id'] = $this->config->get('payment_scpay_geo_zone_id');

		// $this->load->model('localisation/geo_zone');

		// $data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

		$data['payment_scpay_status'] = $this->config->get('payment_scpay_status');
		$data['payment_scpay_sort_order'] = $this->config->get('payment_scpay_sort_order');

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/sc_payments/payment/scpay', $data));
	}

	public function save(): void {
		$this->load->language('extension/sc_payments/payment/scpay');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/sc_payments/payment/scpay')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['payment_scpay_merchant']) {
			$json['merchant'] = $this->language->get('error_merchant');
		}
		
		if (!$this->request->post['payment_scpay_password']) {
			$json['password'] = $this->language->get('error_password');
		}

		if (!$json) {
			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting('payment_scpay', $this->request->post);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}
